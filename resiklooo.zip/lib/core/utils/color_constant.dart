import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color black9004c = fromHex('#4c000000');

  static Color greenA7007f1 = fromHex('#7f00d452');

  static Color gray51 = fromHex('#fff7f2');

  static Color green901 = fromHex('#085e05');

  static Color green900 = fromHex('#0f5703');

  static Color yellow90075 = fromHex('#75fa8214');

  static Color gray101 = fromHex('#fcf7f2');

  static Color gray200 = fromHex('#f0f0f0');

  static Color gray50 = fromHex('#fff5f5');

  static Color gray100 = fromHex('#fcf2f2');

  static Color lightGreen900 = fromHex('#268a03');

  static Color greenA700 = fromHex('#0db34d');

  static Color black900 = fromHex('#000000');

  static Color indigoA700 = fromHex('#001aff');

  static Color greenA7004c = fromHex('#4c0ac21c');

  static Color deepOrange600 = fromHex('#ed661a');

  static Color greenA7007f = fromHex('#7f0db34d');

  static Color black90040 = fromHex('#40000000');

  static Color greenA70019 = fromHex('#190ac21c');

  static Color whiteA700 = fromHex('#ffffff');

  static Color green70019 = fromHex('#19309e3b');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
