class ImageConstant {
  static String imgFacilitycatalo = 'assets/images/img_facilitycatalo.svg';

  static String imgGroup2 = 'assets/images/img_group2.svg';

  static String imgUndrawmaleava1 = 'assets/images/img_undrawmaleava_1.svg';

  static String imgRectangle50 = 'assets/images/img_rectangle50.svg';

  static String imgGroup24 = 'assets/images/img_group2_4.svg';

  static String imgRectangle45 = 'assets/images/img_rectangle45.png';

  static String imgRectangle49 = 'assets/images/img_rectangle49.svg';

  static String imgR3sikl12 = 'assets/images/img_r3sikl1_2.png';

  static String imgUndrawpersonal = 'assets/images/img_undrawpersonal.svg';

  static String imgR3sikl1 = 'assets/images/img_r3sikl1.png';

  static String imgUndrawmaleava2 = 'assets/images/img_undrawmaleava_2.svg';

  static String imgGroup21 = 'assets/images/img_group2_1.svg';

  static String imgGroup66 = 'assets/images/img_group66.svg';

  static String imgVector1 = 'assets/images/img_vector1.svg';

  static String imgFrame12 = 'assets/images/img_frame12.svg';

  static String imgGroup22 = 'assets/images/img_group2_2.svg';

  static String imgUndrawdownload = 'assets/images/img_undrawdownload.svg';

  static String imgGroup25 = 'assets/images/img_group2_5.svg';

  static String imgDownload4re = 'assets/images/img_download4re.png';

  static String imgUndraworderco = 'assets/images/img_undraworderco.svg';

  static String imgUndrawcompleti = 'assets/images/img_undrawcompleti.svg';

  static String imgImages1remo = 'assets/images/img_images1remo.png';

  static String imgImages2remo = 'assets/images/img_images2remo.png';

  static String imgGroup1 = 'assets/images/img_group1.svg';

  static String imgImages3remo = 'assets/images/img_images3remo.png';

  static String imgUndrawenvironm = 'assets/images/img_undrawenvironm.svg';

  static String imgGroup23 = 'assets/images/img_group2_3.svg';

  static String imgRectangle46 = 'assets/images/img_rectangle46.png';

  static String imgUndrawmaleava3 = 'assets/images/img_undrawmaleava_3.svg';

  static String imgUndrawaccessa = 'assets/images/img_undrawaccessa.svg';

  static String imgImagesremovebg = 'assets/images/img_imagesremovebg.png';

  static String imgUndrawmaleava = 'assets/images/img_undrawmaleava.svg';

  static String imgRectangle44 = 'assets/images/img_rectangle44.png';

  static String imgImages1remo1 = 'assets/images/img_images1remo_1.png';

  static String imgDownloadremove1 = 'assets/images/img_downloadremove_1.png';

  static String imgFrame15 = 'assets/images/img_frame15.svg';

  static String imgDownload41 = 'assets/images/img_download41.png';

  static String imgR3sikl11 = 'assets/images/img_r3sikl1_1.png';

  static String imgImages4remo = 'assets/images/img_images4remo.png';

  static String imgDownloadremove = 'assets/images/img_downloadremove.png';

  static String imgAkariconseye = 'assets/images/img_akariconseye.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
