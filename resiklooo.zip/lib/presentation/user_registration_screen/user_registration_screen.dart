import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kugel_s_application/core/app_export.dart';

class UserRegistrationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Container(
          decoration: BoxDecoration(
            color: ColorConstant.whiteA700,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Expanded(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                            height: getVerticalSize(
                              222.00,
                            ),
                            width: size.width,
                            child: Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                      left: getHorizontalSize(
                                        35.00,
                                      ),
                                      top: getVerticalSize(
                                        10.00,
                                      ),
                                      right: getHorizontalSize(
                                        35.00,
                                      ),
                                    ),
                                    child: Container(
                                      alignment: Alignment.center,
                                      height: getVerticalSize(
                                        42.00,
                                      ),
                                      width: getHorizontalSize(
                                        287.00,
                                      ),
                                      padding: EdgeInsets.only(
                                        left: getHorizontalSize(
                                          30.00,
                                        ),
                                        top: getVerticalSize(
                                          6.00,
                                        ),
                                        right: getHorizontalSize(
                                          30.00,
                                        ),
                                        bottom: getVerticalSize(
                                          6.00,
                                        ),
                                      ),
                                      decoration: BoxDecoration(
                                        color: ColorConstant.greenA700,
                                        borderRadius: BorderRadius.circular(
                                          getHorizontalSize(
                                            23.00,
                                          ),
                                        ),
                                      ),
                                      child: Text(
                                        'USER',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: ColorConstant.gray100,
                                          fontSize: getFontSize(
                                            25,
                                          ),
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                      left: getHorizontalSize(
                                        117.00,
                                      ),
                                      top: getVerticalSize(
                                        42.00,
                                      ),
                                      right: getHorizontalSize(
                                        117.00,
                                      ),
                                      bottom: getVerticalSize(
                                        42.00,
                                      ),
                                    ),
                                    child: Text(
                                      "TO BE OUR",
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: ColorConstant.green900,
                                        fontSize: getFontSize(
                                          24,
                                        ),
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                      bottom: getVerticalSize(
                                        10.00,
                                      ),
                                    ),
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                            top: getVerticalSize(
                                              13.00,
                                            ),
                                            bottom: getVerticalSize(
                                              170.37,
                                            ),
                                          ),
                                          child: Container(
                                            height: getVerticalSize(
                                              24.00,
                                            ),
                                            width: getHorizontalSize(
                                              75.00,
                                            ),
                                            child: SvgPicture.asset(
                                              ImageConstant.imgFrame12,
                                              fit: BoxFit.fill,
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(
                                            left: getHorizontalSize(
                                              62.00,
                                            ),
                                          ),
                                          child: Container(
                                            height: getVerticalSize(
                                              207.37,
                                            ),
                                            width: getHorizontalSize(
                                              223.00,
                                            ),
                                            child: SvgPicture.asset(
                                              ImageConstant.imgGroup2,
                                              fit: BoxFit.fill,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: getVerticalSize(
                            29.00,
                          ),
                          width: getHorizontalSize(
                            181.00,
                          ),
                          margin: EdgeInsets.only(
                            left: getHorizontalSize(
                              77.00,
                            ),
                            right: getHorizontalSize(
                              77.00,
                            ),
                          ),
                          child: Stack(
                            alignment: Alignment.centerLeft,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    top: getVerticalSize(
                                      1.00,
                                    ),
                                    bottom: getVerticalSize(
                                      10.00,
                                    ),
                                  ),
                                  child: Text(
                                    "FILL OUT THE FOLLOWING:",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: ColorConstant.green900,
                                      fontSize: getFontSize(
                                        14,
                                      ),
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    left: getHorizontalSize(
                                      76.00,
                                    ),
                                    right: getHorizontalSize(
                                      76.00,
                                    ),
                                  ),
                                  child: Text(
                                    "",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: ColorConstant.green900,
                                      fontSize: getFontSize(
                                        24,
                                      ),
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: getHorizontalSize(
                              10.00,
                            ),
                            top: getVerticalSize(
                              16.00,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                  right: getHorizontalSize(
                                    10.00,
                                  ),
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(
                                        right: getHorizontalSize(
                                          2.00,
                                        ),
                                      ),
                                      child: Text(
                                        "Name",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: ColorConstant.black900,
                                          fontSize: getFontSize(
                                            14,
                                          ),
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: getVerticalSize(
                                        29.00,
                                      ),
                                      width: getHorizontalSize(
                                        324.00,
                                      ),
                                      margin: EdgeInsets.only(
                                        bottom: getVerticalSize(
                                          19.00,
                                        ),
                                      ),
                                      decoration: BoxDecoration(
                                        color: ColorConstant.greenA7004c,
                                        borderRadius: BorderRadius.circular(
                                          getHorizontalSize(
                                            5.00,
                                          ),
                                        ),
                                        border: Border.all(
                                          color: ColorConstant.black9004c,
                                          width: getHorizontalSize(
                                            0.50,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  top: getVerticalSize(
                                    8.00,
                                  ),
                                  right: getHorizontalSize(
                                    10.00,
                                  ),
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(
                                        right: getHorizontalSize(
                                          2.00,
                                        ),
                                      ),
                                      child: Text(
                                        "Phone Number",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: ColorConstant.black900,
                                          fontSize: getFontSize(
                                            14,
                                          ),
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: getVerticalSize(
                                        29.00,
                                      ),
                                      width: getHorizontalSize(
                                        324.00,
                                      ),
                                      margin: EdgeInsets.only(
                                        bottom: getVerticalSize(
                                          19.00,
                                        ),
                                      ),
                                      decoration: BoxDecoration(
                                        color: ColorConstant.greenA7004c,
                                        borderRadius: BorderRadius.circular(
                                          getHorizontalSize(
                                            5.00,
                                          ),
                                        ),
                                        border: Border.all(
                                          color: ColorConstant.black9004c,
                                          width: getHorizontalSize(
                                            0.50,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  top: getVerticalSize(
                                    8.00,
                                  ),
                                  right: getHorizontalSize(
                                    10.00,
                                  ),
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(
                                        right: getHorizontalSize(
                                          2.00,
                                        ),
                                      ),
                                      child: Text(
                                        "Email Address",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: ColorConstant.black900,
                                          fontSize: getFontSize(
                                            14,
                                          ),
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: getVerticalSize(
                                        29.00,
                                      ),
                                      width: getHorizontalSize(
                                        324.00,
                                      ),
                                      margin: EdgeInsets.only(
                                        bottom: getVerticalSize(
                                          19.00,
                                        ),
                                      ),
                                      decoration: BoxDecoration(
                                        color: ColorConstant.greenA7004c,
                                        borderRadius: BorderRadius.circular(
                                          getHorizontalSize(
                                            5.00,
                                          ),
                                        ),
                                        border: Border.all(
                                          color: ColorConstant.black9004c,
                                          width: getHorizontalSize(
                                            0.50,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  66.00,
                                ),
                                width: getHorizontalSize(
                                  324.00,
                                ),
                                margin: EdgeInsets.only(
                                  top: getVerticalSize(
                                    8.00,
                                  ),
                                  right: getHorizontalSize(
                                    10.00,
                                  ),
                                ),
                                child: Stack(
                                  alignment: Alignment.centerLeft,
                                  children: [
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Padding(
                                        padding: EdgeInsets.only(
                                          left: getHorizontalSize(
                                            10.00,
                                          ),
                                          top: getVerticalSize(
                                            21.00,
                                          ),
                                          right: getHorizontalSize(
                                            7.77,
                                          ),
                                          bottom: getVerticalSize(
                                            21.00,
                                          ),
                                        ),
                                        child: Container(
                                          height: getVerticalSize(
                                            24.00,
                                          ),
                                          width: getHorizontalSize(
                                            23.23,
                                          ),
                                          child: SvgPicture.asset(
                                            ImageConstant.imgAkariconseye,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: EdgeInsets.only(
                                              right: getHorizontalSize(
                                                2.00,
                                              ),
                                            ),
                                            child: Text(
                                              "Password",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: ColorConstant.black900,
                                                fontSize: getFontSize(
                                                  14,
                                                ),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            height: getVerticalSize(
                                              29.00,
                                            ),
                                            width: getHorizontalSize(
                                              324.00,
                                            ),
                                            margin: EdgeInsets.only(
                                              bottom: getVerticalSize(
                                                19.00,
                                              ),
                                            ),
                                            decoration: BoxDecoration(
                                              color: ColorConstant.greenA7004c,
                                              borderRadius:
                                                  BorderRadius.circular(
                                                getHorizontalSize(
                                                  5.00,
                                                ),
                                              ),
                                              border: Border.all(
                                                color: ColorConstant.black9004c,
                                                width: getHorizontalSize(
                                                  0.50,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  top: getVerticalSize(
                                    8.00,
                                  ),
                                  right: getHorizontalSize(
                                    10.00,
                                  ),
                                ),
                                child: Container(
                                  alignment: Alignment.center,
                                  height: getVerticalSize(
                                    42.00,
                                  ),
                                  width: getHorizontalSize(
                                    194.00,
                                  ),
                                  padding: EdgeInsets.only(
                                    left: getHorizontalSize(
                                      30.00,
                                    ),
                                    top: getVerticalSize(
                                      6.00,
                                    ),
                                    right: getHorizontalSize(
                                      30.00,
                                    ),
                                    bottom: getVerticalSize(
                                      6.00,
                                    ),
                                  ),
                                  decoration: BoxDecoration(
                                    color: ColorConstant.greenA700,
                                    borderRadius: BorderRadius.circular(
                                      getHorizontalSize(
                                        23.00,
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'REGISTER',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: ColorConstant.gray100,
                                      fontSize: getFontSize(
                                        25,
                                      ),
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.centerRight,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    left: getHorizontalSize(
                                      226.00,
                                    ),
                                    top: getVerticalSize(
                                      15.00,
                                    ),
                                  ),
                                  child: Image.asset(
                                    ImageConstant.imgImagesremovebg,
                                    height: getVerticalSize(
                                      198.00,
                                    ),
                                    width: getHorizontalSize(
                                      116.00,
                                    ),
                                    fit: BoxFit.fill,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
