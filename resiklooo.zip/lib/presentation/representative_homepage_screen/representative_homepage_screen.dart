import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kugel_s_application/core/app_export.dart';

class RepresentativeHomepageScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Container(
          width: size.width,
          child: SingleChildScrollView(
            child: Container(
              decoration: BoxDecoration(
                color: ColorConstant.whiteA700,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          padding: EdgeInsets.only(
                            left: getHorizontalSize(
                              6.00,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Align(
                                alignment: Alignment.centerRight,
                                child: Container(
                                  height: getVerticalSize(
                                    318.29,
                                  ),
                                  width: getHorizontalSize(
                                    359.19,
                                  ),
                                  margin: EdgeInsets.only(
                                    left: getHorizontalSize(
                                      10.00,
                                    ),
                                  ),
                                  child: Stack(
                                    alignment: Alignment.centerRight,
                                    children: [
                                      Align(
                                        alignment: Alignment.bottomLeft,
                                        child: Padding(
                                          padding: EdgeInsets.only(
                                            top: getVerticalSize(
                                              10.00,
                                            ),
                                            right: getHorizontalSize(
                                              10.00,
                                            ),
                                            bottom: getVerticalSize(
                                              6.29,
                                            ),
                                          ),
                                          child: Container(
                                            height: getSize(
                                              92.00,
                                            ),
                                            width: getSize(
                                              92.00,
                                            ),
                                            child: SvgPicture.asset(
                                              ImageConstant.imgUndrawmaleava1,
                                              fit: BoxFit.fill,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.centerRight,
                                        child: Padding(
                                          padding: EdgeInsets.only(
                                            left: getHorizontalSize(
                                              10.00,
                                            ),
                                          ),
                                          child: Container(
                                            height: getVerticalSize(
                                              318.29,
                                            ),
                                            width: getHorizontalSize(
                                              309.19,
                                            ),
                                            child: SvgPicture.asset(
                                              ImageConstant.imgGroup23,
                                              fit: BoxFit.fill,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Name",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: ColorConstant.black900,
                                    fontSize: getFontSize(
                                      18,
                                    ),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: getHorizontalSize(
                              18.00,
                            ),
                            top: getVerticalSize(
                              3.00,
                            ),
                            right: getHorizontalSize(
                              18.00,
                            ),
                          ),
                          child: Container(
                            alignment: Alignment.center,
                            height: getVerticalSize(
                              18.47,
                            ),
                            width: getHorizontalSize(
                              237.00,
                            ),
                            padding: EdgeInsets.only(
                              left: getHorizontalSize(
                                22.00,
                              ),
                              top: getVerticalSize(
                                1.00,
                              ),
                              right: getHorizontalSize(
                                22.00,
                              ),
                              bottom: getVerticalSize(
                                1.47,
                              ),
                            ),
                            decoration: BoxDecoration(
                              color: ColorConstant.greenA7007f,
                            ),
                            child: Text(
                              'Representative I.D Number',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: ColorConstant.black900,
                                fontSize: getFontSize(
                                  13,
                                ),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w300,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: getHorizontalSize(
                              18.00,
                            ),
                            top: getVerticalSize(
                              3.53,
                            ),
                            right: getHorizontalSize(
                              18.00,
                            ),
                          ),
                          child: Container(
                            alignment: Alignment.center,
                            height: getVerticalSize(
                              29.00,
                            ),
                            width: getHorizontalSize(
                              171.00,
                            ),
                            padding: EdgeInsets.only(
                              left: getHorizontalSize(
                                21.50,
                              ),
                              top: getVerticalSize(
                                5.50,
                              ),
                              right: getHorizontalSize(
                                21.50,
                              ),
                              bottom: getVerticalSize(
                                5.50,
                              ),
                            ),
                            decoration: BoxDecoration(
                              color: ColorConstant.greenA700,
                              borderRadius: BorderRadius.circular(
                                getHorizontalSize(
                                  23.00,
                                ),
                              ),
                            ),
                            child: Text(
                              'REPRESENTATIVE',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: ColorConstant.gray100,
                                fontSize: getFontSize(
                                  15,
                                ),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: getHorizontalSize(
                              18.00,
                            ),
                            top: getVerticalSize(
                              27.00,
                            ),
                            right: getHorizontalSize(
                              18.00,
                            ),
                          ),
                          child: Text(
                            "POINT CREDITING SYSTEM",
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: ColorConstant.green900,
                              fontSize: getFontSize(
                                24,
                              ),
                              fontFamily: 'Inter',
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: getHorizontalSize(
                              18.00,
                            ),
                            top: getVerticalSize(
                              13.00,
                            ),
                            right: getHorizontalSize(
                              18.00,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                  right: getHorizontalSize(
                                    2.00,
                                  ),
                                ),
                                child: Text(
                                  "User ID No.",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: ColorConstant.black900,
                                    fontSize: getFontSize(
                                      14,
                                    ),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  29.00,
                                ),
                                width: getHorizontalSize(
                                  324.00,
                                ),
                                margin: EdgeInsets.only(
                                  bottom: getVerticalSize(
                                    19.00,
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: ColorConstant.greenA7004c,
                                  borderRadius: BorderRadius.circular(
                                    getHorizontalSize(
                                      5.00,
                                    ),
                                  ),
                                  border: Border.all(
                                    color: ColorConstant.black9004c,
                                    width: getHorizontalSize(
                                      0.50,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: getHorizontalSize(
                              18.00,
                            ),
                            top: getVerticalSize(
                              8.00,
                            ),
                            right: getHorizontalSize(
                              18.00,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                  right: getHorizontalSize(
                                    2.00,
                                  ),
                                ),
                                child: Text(
                                  "Number of Points to Credit",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: ColorConstant.black900,
                                    fontSize: getFontSize(
                                      14,
                                    ),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              Container(
                                height: getVerticalSize(
                                  29.00,
                                ),
                                width: getHorizontalSize(
                                  324.00,
                                ),
                                margin: EdgeInsets.only(
                                  bottom: getVerticalSize(
                                    19.00,
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: ColorConstant.greenA7004c,
                                  borderRadius: BorderRadius.circular(
                                    getHorizontalSize(
                                      5.00,
                                    ),
                                  ),
                                  border: Border.all(
                                    color: ColorConstant.black9004c,
                                    width: getHorizontalSize(
                                      0.50,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: getVerticalSize(
                            66.00,
                          ),
                          width: getHorizontalSize(
                            324.00,
                          ),
                          margin: EdgeInsets.only(
                            left: getHorizontalSize(
                              18.00,
                            ),
                            top: getVerticalSize(
                              8.00,
                            ),
                            right: getHorizontalSize(
                              18.00,
                            ),
                          ),
                          child: Stack(
                            alignment: Alignment.centerLeft,
                            children: [
                              Align(
                                alignment: Alignment.centerRight,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    left: getHorizontalSize(
                                      10.00,
                                    ),
                                    top: getVerticalSize(
                                      21.00,
                                    ),
                                    right: getHorizontalSize(
                                      7.77,
                                    ),
                                    bottom: getVerticalSize(
                                      21.00,
                                    ),
                                  ),
                                  child: Container(
                                    height: getVerticalSize(
                                      24.00,
                                    ),
                                    width: getHorizontalSize(
                                      23.23,
                                    ),
                                    child: SvgPicture.asset(
                                      ImageConstant.imgAkariconseye,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(
                                        right: getHorizontalSize(
                                          2.00,
                                        ),
                                      ),
                                      child: Text(
                                        "Representative Password",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: ColorConstant.black900,
                                          fontSize: getFontSize(
                                            14,
                                          ),
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: getVerticalSize(
                                        29.00,
                                      ),
                                      width: getHorizontalSize(
                                        324.00,
                                      ),
                                      margin: EdgeInsets.only(
                                        bottom: getVerticalSize(
                                          19.00,
                                        ),
                                      ),
                                      decoration: BoxDecoration(
                                        color: ColorConstant.greenA7004c,
                                        borderRadius: BorderRadius.circular(
                                          getHorizontalSize(
                                            5.00,
                                          ),
                                        ),
                                        border: Border.all(
                                          color: ColorConstant.black9004c,
                                          width: getHorizontalSize(
                                            0.50,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(
                              left: getHorizontalSize(
                                18.00,
                              ),
                              top: getVerticalSize(
                                8.00,
                              ),
                              right: getHorizontalSize(
                                206.00,
                              ),
                            ),
                            child: Container(
                              alignment: Alignment.center,
                              height: getVerticalSize(
                                42.00,
                              ),
                              width: getHorizontalSize(
                                136.00,
                              ),
                              padding: EdgeInsets.only(
                                left: getHorizontalSize(
                                  30.00,
                                ),
                                top: getVerticalSize(
                                  6.00,
                                ),
                                right: getHorizontalSize(
                                  30.00,
                                ),
                                bottom: getVerticalSize(
                                  6.00,
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: ColorConstant.greenA700,
                                borderRadius: BorderRadius.circular(
                                  getHorizontalSize(
                                    23.00,
                                  ),
                                ),
                              ),
                              child: Text(
                                'Send',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: ColorConstant.gray100,
                                  fontSize: getFontSize(
                                    25,
                                  ),
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                            padding: EdgeInsets.only(
                              left: getHorizontalSize(
                                160.00,
                              ),
                              top: getVerticalSize(
                                45.00,
                              ),
                            ),
                            child: Container(
                              height: getVerticalSize(
                                174.00,
                              ),
                              width: getHorizontalSize(
                                200.00,
                              ),
                              child: SvgPicture.asset(
                                ImageConstant.imgUndrawdownload,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
