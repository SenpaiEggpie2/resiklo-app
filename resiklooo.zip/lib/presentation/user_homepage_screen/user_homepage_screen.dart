import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kugel_s_application/core/app_export.dart';

class UserHomepageScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Container(
          width: size.width,
          child: SingleChildScrollView(
            child: Container(
              decoration: BoxDecoration(
                color: ColorConstant.whiteA700,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: EdgeInsets.only(
                        bottom: getVerticalSize(
                          26.00,
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.centerRight,
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              padding: EdgeInsets.only(
                                left: getHorizontalSize(
                                  20.00,
                                ),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(
                                      top: getVerticalSize(
                                        240.00,
                                      ),
                                      bottom: getVerticalSize(
                                        33.29,
                                      ),
                                    ),
                                    child: Container(
                                      height: getVerticalSize(
                                        45.00,
                                      ),
                                      width: getHorizontalSize(
                                        107.54,
                                      ),
                                      child: SvgPicture.asset(
                                        ImageConstant.imgGroup66,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                      left: getHorizontalSize(
                                        62.46,
                                      ),
                                    ),
                                    child: Container(
                                      height: getVerticalSize(
                                        318.29,
                                      ),
                                      width: getHorizontalSize(
                                        309.19,
                                      ),
                                      child: SvgPicture.asset(
                                        ImageConstant.imgGroup25,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: Padding(
                              padding: EdgeInsets.only(
                                left: getHorizontalSize(
                                  19.00,
                                ),
                                top: getVerticalSize(
                                  8.02,
                                ),
                                right: getHorizontalSize(
                                  19.00,
                                ),
                              ),
                              child: Container(
                                height: getVerticalSize(
                                  17.94,
                                ),
                                width: getHorizontalSize(
                                  250.81,
                                ),
                                child: SvgPicture.asset(
                                  ImageConstant.imgFacilitycatalo,
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: Padding(
                              padding: EdgeInsets.only(
                                left: getHorizontalSize(
                                  19.00,
                                ),
                                top: getVerticalSize(
                                  21.75,
                                ),
                                right: getHorizontalSize(
                                  19.00,
                                ),
                              ),
                              child: Container(
                                height: getVerticalSize(
                                  549.00,
                                ),
                                width: getHorizontalSize(
                                  320.00,
                                ),
                                child: SvgPicture.asset(
                                  ImageConstant.imgFrame15,
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
