import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kugel_s_application/core/app_export.dart';

class Registration1Screen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Container(
          decoration: BoxDecoration(
            color: ColorConstant.whiteA700,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Expanded(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                      top: getVerticalSize(
                        13.00,
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                padding: EdgeInsets.only(
                                  right: getHorizontalSize(
                                    10.00,
                                  ),
                                ),
                                child: Container(
                                  height: getVerticalSize(
                                    24.00,
                                  ),
                                  width: getHorizontalSize(
                                    75.00,
                                  ),
                                  child: SvgPicture.asset(
                                    ImageConstant.imgFrame12,
                                    fit: BoxFit.fill,
                                  ),
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Padding(
                                padding: EdgeInsets.only(
                                  left: getHorizontalSize(
                                    44.00,
                                  ),
                                  top: getVerticalSize(
                                    25.00,
                                  ),
                                  right: getHorizontalSize(
                                    44.00,
                                  ),
                                ),
                                child: Image.asset(
                                  ImageConstant.imgR3sikl12,
                                  height: getVerticalSize(
                                    53.00,
                                  ),
                                  width: getHorizontalSize(
                                    210.00,
                                  ),
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Padding(
                                padding: EdgeInsets.only(
                                  left: getHorizontalSize(
                                    44.00,
                                  ),
                                  top: getVerticalSize(
                                    45.00,
                                  ),
                                  right: getHorizontalSize(
                                    44.00,
                                  ),
                                ),
                                child: Container(
                                  height: getVerticalSize(
                                    176.00,
                                  ),
                                  width: getHorizontalSize(
                                    263.00,
                                  ),
                                  child: SvgPicture.asset(
                                    ImageConstant.imgUndrawpersonal,
                                    fit: BoxFit.fill,
                                  ),
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                padding: EdgeInsets.only(
                                  top: getVerticalSize(
                                    35.00,
                                  ),
                                ),
                                child: Text(
                                  "You are registering as:",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: ColorConstant.black900,
                                    fontSize: getFontSize(
                                      17,
                                    ),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Padding(
                                padding: EdgeInsets.only(
                                  left: getHorizontalSize(
                                    44.00,
                                  ),
                                  top: getVerticalSize(
                                    25.00,
                                  ),
                                  right: getHorizontalSize(
                                    44.00,
                                  ),
                                ),
                                child: Container(
                                  alignment: Alignment.center,
                                  height: getVerticalSize(
                                    76.00,
                                  ),
                                  width: getHorizontalSize(
                                    245.00,
                                  ),
                                  padding: EdgeInsets.only(
                                    left: getHorizontalSize(
                                      30.00,
                                    ),
                                    top: getVerticalSize(
                                      23.00,
                                    ),
                                    right: getHorizontalSize(
                                      30.00,
                                    ),
                                    bottom: getVerticalSize(
                                      23.00,
                                    ),
                                  ),
                                  decoration: BoxDecoration(
                                    color: ColorConstant.greenA700,
                                    borderRadius: BorderRadius.circular(
                                      getHorizontalSize(
                                        23.00,
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'User',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: ColorConstant.gray100,
                                      fontSize: getFontSize(
                                        25,
                                      ),
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Padding(
                                padding: EdgeInsets.only(
                                  left: getHorizontalSize(
                                    44.00,
                                  ),
                                  right: getHorizontalSize(
                                    44.00,
                                  ),
                                ),
                                child: Text(
                                  "for consumers",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: ColorConstant.black900,
                                    fontSize: getFontSize(
                                      18,
                                    ),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w300,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Container(
                          height: getVerticalSize(
                            424.37,
                          ),
                          width: getHorizontalSize(
                            298.00,
                          ),
                          margin: EdgeInsets.only(
                            top: getVerticalSize(
                              10.00,
                            ),
                            right: getHorizontalSize(
                              10.00,
                            ),
                          ),
                          child: Stack(
                            alignment: Alignment.topRight,
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Padding(
                                        padding: EdgeInsets.only(
                                          left: getHorizontalSize(
                                            10.00,
                                          ),
                                        ),
                                        child: Container(
                                          alignment: Alignment.center,
                                          height: getVerticalSize(
                                            76.00,
                                          ),
                                          width: getHorizontalSize(
                                            245.00,
                                          ),
                                          padding: EdgeInsets.only(
                                            left: getHorizontalSize(
                                              30.00,
                                            ),
                                            top: getVerticalSize(
                                              23.00,
                                            ),
                                            right: getHorizontalSize(
                                              30.00,
                                            ),
                                            bottom: getVerticalSize(
                                              23.00,
                                            ),
                                          ),
                                          decoration: BoxDecoration(
                                            color: ColorConstant.greenA700,
                                            borderRadius: BorderRadius.circular(
                                              getHorizontalSize(
                                                23.00,
                                              ),
                                            ),
                                          ),
                                          child: Text(
                                            'Representative',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              color: ColorConstant.gray100,
                                              fontSize: getFontSize(
                                                25,
                                              ),
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                        padding: EdgeInsets.only(
                                          right: getHorizontalSize(
                                            10.00,
                                          ),
                                        ),
                                        child: Container(
                                          height: getVerticalSize(
                                            351.37,
                                          ),
                                          width: getHorizontalSize(
                                            202.57,
                                          ),
                                          child: SvgPicture.asset(
                                            ImageConstant.imgGroup1,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Align(
                                alignment: Alignment.topRight,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    left: getHorizontalSize(
                                      10.00,
                                    ),
                                    top: getVerticalSize(
                                      82.00,
                                    ),
                                    right: getHorizontalSize(
                                      2.00,
                                    ),
                                    bottom: getVerticalSize(
                                      82.00,
                                    ),
                                  ),
                                  child: Text(
                                    "for facility employees",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: ColorConstant.black900,
                                      fontSize: getFontSize(
                                        18,
                                      ),
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w300,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
