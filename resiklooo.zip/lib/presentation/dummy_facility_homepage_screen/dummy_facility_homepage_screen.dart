import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kugel_s_application/core/app_export.dart';

class DummyFacilityHomepageScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Container(
          width: size.width,
          child: SingleChildScrollView(
            child: Container(
              decoration: BoxDecoration(
                color: ColorConstant.whiteA700,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: ColorConstant.gray101,
                        boxShadow: [
                          BoxShadow(
                            color: ColorConstant.black90040,
                            spreadRadius: getHorizontalSize(
                              2.00,
                            ),
                            blurRadius: getHorizontalSize(
                              2.00,
                            ),
                            offset: Offset(
                              0,
                              2,
                            ),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            height: getVerticalSize(
                              270.00,
                            ),
                            width: getHorizontalSize(
                              326.00,
                            ),
                            margin: EdgeInsets.only(
                              right: getHorizontalSize(
                                10.00,
                              ),
                            ),
                            child: Stack(
                              alignment: Alignment.bottomRight,
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                      right: getHorizontalSize(
                                        10.00,
                                      ),
                                      bottom: getVerticalSize(
                                        10.00,
                                      ),
                                    ),
                                    child: Container(
                                      height: getVerticalSize(
                                        201.55,
                                      ),
                                      width: getHorizontalSize(
                                        236.58,
                                      ),
                                      child: SvgPicture.asset(
                                        ImageConstant.imgGroup24,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.bottomRight,
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                      left: getHorizontalSize(
                                        10.00,
                                      ),
                                      top: getVerticalSize(
                                        10.00,
                                      ),
                                    ),
                                    child: Image.asset(
                                      ImageConstant.imgDownloadremove1,
                                      height: getVerticalSize(
                                        174.00,
                                      ),
                                      width: getHorizontalSize(
                                        290.00,
                                      ),
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: Padding(
                              padding: EdgeInsets.only(
                                left: getHorizontalSize(
                                  1.00,
                                ),
                                top: getVerticalSize(
                                  6.00,
                                ),
                                bottom: getVerticalSize(
                                  4.00,
                                ),
                              ),
                              child: Text(
                                "Facility Name",
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: ColorConstant.black900,
                                  fontSize: getFontSize(
                                    18,
                                  ),
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: EdgeInsets.only(
                        left: getHorizontalSize(
                          11.00,
                        ),
                        top: getVerticalSize(
                          44.00,
                        ),
                        right: getHorizontalSize(
                          11.00,
                        ),
                      ),
                      child: Text(
                        "CONTACT DETAILS",
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: ColorConstant.green900,
                          fontSize: getFontSize(
                            18,
                          ),
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      width: getHorizontalSize(
                        235.00,
                      ),
                      margin: EdgeInsets.only(
                        left: getHorizontalSize(
                          11.00,
                        ),
                        top: getVerticalSize(
                          22.00,
                        ),
                        right: getHorizontalSize(
                          11.00,
                        ),
                        bottom: getVerticalSize(
                          20.00,
                        ),
                      ),
                      decoration: BoxDecoration(
                        color: ColorConstant.greenA7007f1,
                        borderRadius: BorderRadius.circular(
                          getHorizontalSize(
                            33.00,
                          ),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(
                              left: getHorizontalSize(
                                66.00,
                              ),
                              top: getVerticalSize(
                                28.00,
                              ),
                              right: getHorizontalSize(
                                61.00,
                              ),
                            ),
                            child: Container(
                              alignment: Alignment.center,
                              height: getVerticalSize(
                                17.00,
                              ),
                              width: getHorizontalSize(
                                108.00,
                              ),
                              padding: EdgeInsets.only(
                                left: getHorizontalSize(
                                  30.00,
                                ),
                                top: getVerticalSize(
                                  2.50,
                                ),
                                right: getHorizontalSize(
                                  30.00,
                                ),
                                bottom: getVerticalSize(
                                  2.50,
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: ColorConstant.greenA700,
                                borderRadius: BorderRadius.circular(
                                  getHorizontalSize(
                                    23.00,
                                  ),
                                ),
                              ),
                              child: Text(
                                'USER',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: ColorConstant.gray100,
                                  fontSize: getFontSize(
                                    10,
                                  ),
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                              left: getHorizontalSize(
                                66.00,
                              ),
                              top: getVerticalSize(
                                7.00,
                              ),
                              right: getHorizontalSize(
                                66.00,
                              ),
                            ),
                            child: Container(
                              height: getSize(
                                78.00,
                              ),
                              width: getSize(
                                78.00,
                              ),
                              child: SvgPicture.asset(
                                ImageConstant.imgUndrawmaleava2,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                              left: getHorizontalSize(
                                66.00,
                              ),
                              top: getVerticalSize(
                                12.00,
                              ),
                              right: getHorizontalSize(
                                61.00,
                              ),
                            ),
                            child: Container(
                              alignment: Alignment.center,
                              height: getVerticalSize(
                                17.00,
                              ),
                              width: getHorizontalSize(
                                108.00,
                              ),
                              padding: EdgeInsets.only(
                                left: getHorizontalSize(
                                  30.00,
                                ),
                                top: getVerticalSize(
                                  2.50,
                                ),
                                right: getHorizontalSize(
                                  30.00,
                                ),
                                bottom: getVerticalSize(
                                  2.50,
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: ColorConstant.greenA700,
                                borderRadius: BorderRadius.circular(
                                  getHorizontalSize(
                                    23.00,
                                  ),
                                ),
                              ),
                              child: Text(
                                'Name',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: ColorConstant.gray100,
                                  fontSize: getFontSize(
                                    10,
                                  ),
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                              left: getHorizontalSize(
                                66.00,
                              ),
                              top: getVerticalSize(
                                7.00,
                              ),
                              right: getHorizontalSize(
                                61.00,
                              ),
                            ),
                            child: Container(
                              alignment: Alignment.center,
                              height: getVerticalSize(
                                17.00,
                              ),
                              width: getHorizontalSize(
                                108.00,
                              ),
                              padding: EdgeInsets.only(
                                left: getHorizontalSize(
                                  18.50,
                                ),
                                top: getVerticalSize(
                                  2.50,
                                ),
                                right: getHorizontalSize(
                                  18.50,
                                ),
                                bottom: getVerticalSize(
                                  2.50,
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: ColorConstant.greenA700,
                                borderRadius: BorderRadius.circular(
                                  getHorizontalSize(
                                    23.00,
                                  ),
                                ),
                              ),
                              child: Text(
                                'Phone Number',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: ColorConstant.gray100,
                                  fontSize: getFontSize(
                                    10,
                                  ),
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                              padding: EdgeInsets.only(
                                top: getVerticalSize(
                                  24.00,
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                        left: getHorizontalSize(
                                          25.00,
                                        ),
                                        right: getHorizontalSize(
                                          25.00,
                                        ),
                                      ),
                                      child: Container(
                                        alignment: Alignment.center,
                                        height: getVerticalSize(
                                          17.00,
                                        ),
                                        width: getHorizontalSize(
                                          108.00,
                                        ),
                                        padding: EdgeInsets.only(
                                          left: getHorizontalSize(
                                            30.00,
                                          ),
                                          top: getVerticalSize(
                                            2.50,
                                          ),
                                          right: getHorizontalSize(
                                            30.00,
                                          ),
                                          bottom: getVerticalSize(
                                            2.50,
                                          ),
                                        ),
                                        decoration: BoxDecoration(
                                          color: ColorConstant.greenA700,
                                          borderRadius: BorderRadius.circular(
                                            getHorizontalSize(
                                              23.00,
                                            ),
                                          ),
                                        ),
                                        child: Text(
                                          'Address',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: ColorConstant.gray100,
                                            fontSize: getFontSize(
                                              10,
                                            ),
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                        left: getHorizontalSize(
                                          29.00,
                                        ),
                                        top: getVerticalSize(
                                          6.00,
                                        ),
                                        right: getHorizontalSize(
                                          29.00,
                                        ),
                                      ),
                                      child: Text(
                                        "123 Marites Batumbakal St.",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: ColorConstant.black900,
                                          fontSize: getFontSize(
                                            12,
                                          ),
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                              padding: EdgeInsets.only(
                                top: getVerticalSize(
                                  25.00,
                                ),
                                bottom: getVerticalSize(
                                  20.00,
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                        left: getHorizontalSize(
                                          28.00,
                                        ),
                                        right: getHorizontalSize(
                                          28.00,
                                        ),
                                      ),
                                      child: Container(
                                        alignment: Alignment.center,
                                        height: getVerticalSize(
                                          17.00,
                                        ),
                                        width: getHorizontalSize(
                                          108.00,
                                        ),
                                        padding: EdgeInsets.only(
                                          left: getHorizontalSize(
                                            14.50,
                                          ),
                                          top: getVerticalSize(
                                            2.50,
                                          ),
                                          right: getHorizontalSize(
                                            14.50,
                                          ),
                                          bottom: getVerticalSize(
                                            2.50,
                                          ),
                                        ),
                                        decoration: BoxDecoration(
                                          color: ColorConstant.greenA700,
                                          borderRadius: BorderRadius.circular(
                                            getHorizontalSize(
                                              23.00,
                                            ),
                                          ),
                                        ),
                                        child: Text(
                                          'Operating Hours',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: ColorConstant.gray100,
                                            fontSize: getFontSize(
                                              10,
                                            ),
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                        left: getHorizontalSize(
                                          29.00,
                                        ),
                                        top: getVerticalSize(
                                          7.00,
                                        ),
                                        right: getHorizontalSize(
                                          29.00,
                                        ),
                                      ),
                                      child: Text(
                                        "Monday to Friday\n8:00AM to 5:00PM",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: ColorConstant.black900,
                                          fontSize: getFontSize(
                                            12,
                                          ),
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
